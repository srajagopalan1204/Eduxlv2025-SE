# Eduxlv2025-SE — TechMobile Pilot (roles + checklist)

- Production-only login + role gating (UI).
- Staging envs (Unit_staging, Integrated_Testing) are open.
- Palco → Service → TechMobile navigation, plus SOP viewer.
- Private checklist at `docs/private/checklist.html` (browser-saved).

Users:
- trainer1 / Welcome1! (roles: Scott, Palco)
- viewer1 / Scott123 (roles: Palco:Service:TechMobile)
