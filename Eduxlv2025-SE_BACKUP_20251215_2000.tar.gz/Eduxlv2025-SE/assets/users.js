window.__USERS = {
  "salt": "scott-training-v1",
  "users": [
    { "u": "trainer1", "h": "d38b27ed1a6d251a87e89136689fda23eaa031db5d8c0ce8e33bd97cc48a8181", "roles": ["Scott","Palco"] },
    { "u": "viewer1",  "h": "1a664c4d2f8b61073a10de75d47fe909ee58e6653d781a1d46a0c2b8a4f6a152", "roles": ["Palco:Service:TechMobile"] }
  ]
};
