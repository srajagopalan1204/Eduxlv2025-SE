#!/usr/bin/env python3
"""
patch_images.py — Option 2B utility
- Versioned filenames for images stored under /SOP/...
- Update references in env JSON snapshots and optional CSVs by Code, scoped by SOP path.
Usage:
  python scripts/patch_images.py \
    --sop "SOP/Tech/TechMobile" \
    --map "/path/to/patch_map.csv" \
    --env-root "./env" \
    [--csv-dir "./SOP/csv"]
CSV format (header):
  SOP_path,Code,new_image
Example row:
  SOP/Tech/TechMobile,G1,/SOP/images/Tech/G1_v2.png
"""
import argparse, json, csv, os, sys, glob

def load_map(csv_path):
    rows = []
    with open(csv_path, newline="", encoding="utf-8") as f:
        for i, row in enumerate(csv.DictReader(f)):
            # expected columns: SOP_path, Code, new_image
            sop = (row.get("SOP_path") or "").strip()
            code = (row.get("Code") or "").strip()
            new_img = (row.get("new_image") or "").strip()
            if not sop or not code or not new_img:
                print(f"[WARN] row {i+2}: missing column(s), skipping")
                continue
            rows.append((sop, code, new_img))
    return rows

def update_env_json(env_dir, mapping):
    changed = 0
    for jf in ["story.json", "all_story.json"]:
        path = os.path.join(env_dir, jf)
        if not os.path.exists(path):
            continue
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception as e:
            print(f"[ERROR] reading {path}: {e}")
            continue

        # items may be list or dict with "items"
        items = data if isinstance(data, list) else data.get("items", [])
        any_change = False
        for sop_path, code, new_img in mapping:
            for it in items:
                if it.get("SOP_path") == sop_path and it.get("Code") == code:
                    it["Image_sub_url"] = new_img
                    any_change = True
                    changed += 1

        # write back
        if any_change:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)
            print(f"[OK] updated {path}")
    return changed

def update_csv_dir(csv_dir, mapping):
    if not csv_dir or not os.path.isdir(csv_dir):
        return 0
    changed = 0
    for csv_path in glob.glob(os.path.join(csv_dir, "*.csv")):
        try:
            with open(csv_path, newline="", encoding="utf-8") as f:
                reader = list(csv.DictReader(f))
            fieldnames = reader[0].keys() if reader else []
            if "Code" not in fieldnames or "Image_sub_url" not in fieldnames or "SOP_path" not in fieldnames:
                continue
            updated = False
            for sop_path, code, new_img in mapping:
                for row in reader:
                    if row.get("SOP_path") == sop_path and row.get("Code") == code:
                        row["Image_sub_url"] = new_img
                        updated = True
                        changed += 1
            if updated:
                with open(csv_path, "w", newline="", encoding="utf-8") as f:
                    w = csv.DictWriter(f, fieldnames=fieldnames)
                    w.writeheader()
                    w.writerows(reader)
                print(f"[OK] updated {csv_path}")
        except Exception as e:
            print(f"[ERROR] csv {csv_path}: {e}")
    return changed

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sop", required=True, help="SOP path prefix, e.g., 'SOP/Tech/TechMobile'")
    ap.add_argument("--map", required=True, help="CSV mapping file path")
    ap.add_argument("--env-root", default="./env", help="Root containing env folders (Unit_staging, Integrated_Testing, Production)")
    ap.add_argument("--csv-dir", default="", help="Optional directory of source CSVs to patch in place")
    args = ap.parse_args()

    mapping_all = [x for x in load_map(args.map) if x[0].startswith(args.sop)]
    if not mapping_all:
        print("[INFO] no mapping rows matched the --sop filter; nothing to do.")
        return 0

    total = 0
    for env in ["Unit_staging", "Integrated_Testing", "Production"]:
        env_dir = os.path.join(args.env_root, env)
        total += update_env_json(env_dir, mapping_all)

    total += update_csv_dir(args.csv_dir, mapping_all)
    print(f"[DONE] Refs updated: {total}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
