#!/usr/bin/env python3
"""
promote.py — Environment promotion helper
- Unit_staging -> Integrated_Testing (merge current + new changes)
- Integrated_Testing -> Production (copy snapshot)
Backups stored under ./backups/YYYYMMDD_HHMM/<ENV>/
Usage:
  python scripts/promote.py --from Unit_staging --to Integrated_Testing --message "QA build"
  python scripts/promote.py --from Integrated_Testing --to Production --message "Release 2025-10-23"
Merging rules (for JSON files story.json, all_story.json):
- Union by ("SOP_path","Code"), with source (--from) overriding on conflicts.
- Preserve items not present in source.
"""
import argparse, os, json, shutil, datetime
from pathlib import Path

KEYS = ("SOP_path","Code")

def backup_env(env_dir: Path, backups_dir: Path, label: str):
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M")
    dest = backups_dir / ts / env_dir.name
    dest.mkdir(parents=True, exist_ok=True)
    for jf in ["nav_config.json", "story.json", "all_story.json"]:
        src = env_dir / jf
        if src.exists():
            shutil.copy2(src, dest / jf)
    (dest / "LABEL.txt").write_text(label, encoding="utf-8")
    return dest

def load_items(json_path: Path):
    if not json_path.exists(): return []
    data = json.loads(json_path.read_text(encoding="utf-8"))
    if isinstance(data, list): return data
    return data.get("items", [])

def save_items(json_path: Path, items):
    # Keep original shape if it was dict; default to array otherwise
    try:
        data = json.loads(json_path.read_text(encoding="utf-8"))
        if isinstance(data, dict) and "items" in data:
            data["items"] = items
        else:
            data = items
    except Exception:
        data = items
    json_path.write_text(json.dumps(data, indent=2), encoding="utf-8")

def index_by_key(items):
    return { (it.get(KEYS[0]), it.get(KEYS[1])): it for it in items }

def merge_story(src_items, dst_items):
    idx = index_by_key(dst_items)
    for it in src_items:
        key = (it.get(KEYS[0]), it.get(KEYS[1]))
        idx[key] = it  # override / add
    # retain items not overridden
    return list(idx.values())

def promote(from_env: str, to_env: str, root: Path, backups: Path, message: str):
    from_dir = root / "env" / from_env
    to_dir   = root / "env" / to_env
    if not from_dir.exists() or not to_dir.exists():
        raise SystemExit(f"Env not found: {from_dir} or {to_dir}")

    # Backup target first
    backup_env(to_dir, backups, f"Before promotion to {to_env}: {message}")

    # nav_config: copy (source of truth per env)
    shutil.copy2(from_dir / "nav_config.json", to_dir / "nav_config.json")

    # story/all_story: merge or copy
    for jf in ["story.json", "all_story.json"]:
        src_p = from_dir / jf
        dst_p = to_dir / jf
        if from_env == "Unit_staging" and to_env == "Integrated_Testing":
            merged = merge_story(load_items(src_p), load_items(dst_p))
            save_items(dst_p, merged)
        else:
            # copy for Integrated_Testing -> Production
            shutil.copy2(src_p, dst_p)

    print(f"[OK] Promoted {from_env} -> {to_env}")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--from", dest="from_env", required=True, choices=["Unit_staging","Integrated_Testing"])
    ap.add_argument("--to", dest="to_env", required=True, choices=["Integrated_Testing","Production"])
    ap.add_argument("--message", default="")
    args = ap.parse_args()

    root = Path(".").resolve()
    backups = root / "backups"
    backups.mkdir(exist_ok=True)

    promote(args.from_env, args.to_env, root, backups, args.message)

if __name__ == "__main__":
    main()
