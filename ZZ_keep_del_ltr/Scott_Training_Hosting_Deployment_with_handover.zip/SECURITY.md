# Security Notes

- This repo is a **portfolio-friendly** static site. Do not store secrets.
- Login is a **demonstration gate** (static hash list). Treat it as light obfuscation, not strong auth.
- If stronger auth is required, plan an SSO-backed gateway in front of the static site.