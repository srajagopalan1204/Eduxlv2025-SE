# Ownership

- **Current Owner:** Subi Rajagopalan (@srajagopalan1204)
- **Repository:** Eduxlv2025-SE (proposed name)

## Succession / Transfer
If you need to hand over:
1. Add the new maintainer as a collaborator.
2. Transfer ownership (GitHub → Settings → Danger Zone → Transfer ownership).
3. Verify GitHub Pages and branch protection settings after transfer.

## License
MIT (change if you need a different license).