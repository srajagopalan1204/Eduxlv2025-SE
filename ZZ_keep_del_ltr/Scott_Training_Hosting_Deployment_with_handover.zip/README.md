# Scott Training – Hosting & Deployment

**Environments**
- `/Unit_staging/` — single SOP under development
- `/Integrated_Testing/` — merged current production + new changes for QA
- `/Production/` — live, approved content

**Shared Assets**
- `/SOP/images/...` and `/SOP/csv/...` are shared by all environments.
- Each environment references these by URL; no "auto-pick latest."

**Data Snapshots (per environment)**
- `env/<ENV>/nav_config.json`
- `env/<ENV>/story.json` (array of items with `SOP_path`, `Code`, `Image_sub_url`, etc.)
- `env/<ENV>/all_story.json` (object with `items: [...]`)

**Promotion**
- Use `python scripts/promote.py --from Unit_staging --to Integrated_Testing --message "QA build"`
- Then `python scripts/promote.py --from Integrated_Testing --to Production --message "Release ..."`
- Backups stored in `backups/YYYYMMDD_HHMM/<ENV>/`

**Image Patch (Option 2B)**
- Prepare a CSV like `SOP/patch_map_example.csv` with columns: `SOP_path,Code,new_image`
- Run: `python scripts/patch_images.py --sop "SOP/Tech/TechMobile" --map SOP/patch_map_example.csv --env-root ./env --csv-dir ./SOP/csv`
- This updates JSON snapshots in all three environments and any matching CSVs in `/SOP/csv`.

**Login**
- Visit `/login.html` → authenticates using static `/assets/users.json` and redirects to `/Production/index.html`.
- Change passwords by editing `assets/users.json` and recomputing hashes as `sha256(salt + "user:password")`.

**Dev Notes**
- All HTML pages include `/assets/gate.js` to ensure the session token exists.
- Replace placeholder images in `/SOP/images/...` with real assets. Keep versioned filenames (`*_v2.png`, etc.).


## Maintainer & Handover
See:
- `OWNERSHIP.md` (current owner, transfer)
- `docs/HANDOVER.md` (step-by-step handover)
- `docs/OPERATIONS.md` (runbook)
- `docs/RELEASES.md` (release flow)
- `CODEOWNERS` + branch protection for solo maintainer safety
