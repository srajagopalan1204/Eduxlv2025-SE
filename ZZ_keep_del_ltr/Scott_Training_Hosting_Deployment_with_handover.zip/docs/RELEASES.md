# Releases

## Flow
1. Finalize in `Integrated_Testing`.
2. Promote to `Production`:
```
python scripts/promote.py --from Integrated_Testing --to Production --message "Release YYYY-MM-DD"
```
3. Tag:
```
git tag -a vYYYY.MM.DD-prod -m "Production release YYYY-MM-DD"
git push --tags
```
4. (Optional) Create a GitHub Release using the tag. Attach any notes and the ZIP snapshot if desired.

## Versioning
- Use calendar versioning for clarity (`v2025.10.23-prod`).