# Handover Guide

## Scope
This repo hosts *Scott Training – Hosting & Deployment* with three environments and shared SOP assets.

## Checkpoints
- Branch protection on `main`
- CODEOWNERS points to @srajagopalan1204
- GitHub Pages is enabled (see OPERATIONS.md)
- Backups exist under `/backups` and remote mirror (optional)

## Secrets
This repo should NOT contain sensitive data. The login gate is a demo UX (static hash list).

## How to rotate login
1. Choose a new salt and passwords.
2. Compute `sha256(salt + "user:password")` hashes.
3. Update `/assets/users.json` and deploy.

## Promotion
- Unit → Integrated: merge by `(SOP_path, Code)`
- Integrated → Production: copy snapshot
- Scripts are in `/scripts`

## Release tagging
- After promoting to Production, tag `vYYYY.MM.DD-prod` and push tags.

## Contact map (update as needed)
- Scott Electric stakeholders: <add>
- Palco stakeholders: <add>