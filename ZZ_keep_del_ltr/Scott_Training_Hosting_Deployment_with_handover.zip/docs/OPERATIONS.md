# Operations

## Daily Tasks
- Patch images using `scripts/patch_images.py` if a slide is versioned (Option 2B).
- Promote environments intentionally using `scripts/promote.py`.

## GitHub Pages (static hosting)
- Recommended: serve from root (`/`).
- Ensure `login.html` is reachable and env shells are under `/Production`, `/Integrated_Testing`, `/Unit_staging`.

### Minimal dev server
Use any static server for local testing, e.g.:
```
python -m http.server 8080
# then open http://localhost:8080/login.html
```

## Backups
- Promotion script writes to `/backups/YYYYMMDD_HHMM/<ENV>/`.
- Optionally mirror the repo:
```
git push --mirror git@github.com:<your-username>/khata_punji.git
```

## Troubleshooting
- 403 on env pages → not logged in (session missing). Go to `/login.html`.
- Missing images → path mismatch; check `/SOP/images/...` and `Image_sub_url` in env JSON.