
(function(){
  const token = sessionStorage.getItem("scott_auth");
  if(!token){
    window.location.replace("/login.html");
  }
})();
