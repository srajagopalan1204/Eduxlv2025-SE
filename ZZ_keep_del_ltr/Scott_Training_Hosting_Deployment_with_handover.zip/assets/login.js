
async function sha256Hex(s) {
  const enc = new TextEncoder();
  const data = enc.encode(s);
  const hash = await crypto.subtle.digest('SHA-256', data);
  const bytes = Array.from(new Uint8Array(hash));
  return bytes.map(b => b.toString(16).padStart(2,"0")).join("");
}

async function doLogin(e){
  e.preventDefault();
  const u = document.getElementById("username").value.trim();
  const p = document.getElementById("password").value;
  const msg = document.getElementById("msg");
  try {
    const resp = await fetch("/assets/users.json", {cache: "no-store"});
    const conf = await resp.json();
    const candidate = await sha256Hex(conf.salt + `${u}:${p}`);
    const ok = conf.users.some(x => x.u === u && x.h === candidate);
    if(ok){
      const token = await sha256Hex(conf.salt + u + Date.now());
      sessionStorage.setItem("scott_auth", token);
      sessionStorage.setItem("scott_user", u);
      window.location.href = "/Production/index.html";
    } else {
      msg.textContent = "Invalid credentials.";
    }
  } catch (err){
    msg.textContent = "Login error. Try again.";
  }
}

document.getElementById("login-form").addEventListener("submit", doLogin);
